from flask_wtf import FlaskForm
from wtforms import BooleanField, SubmitField, IntegerField, StringField, SelectField
from wtforms.validators import DataRequired


class JobForm(FlaskForm):
    job = StringField('job title', validators=[DataRequired()])
    team_leader = SelectField('Team leader ID', choices=[], validate_choice=False)
    work_size = IntegerField('Work Size', validators=[DataRequired()])
    is_finished = BooleanField('Is job finished?')
    collaborators = StringField('Collaborators', validators=[DataRequired()])
    submit = SubmitField('Сохранить')
